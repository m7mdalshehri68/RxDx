# RxDx

Clinical documentation, coding and pre-authorisation support. One HTML file.
**Patient data never leaves the device** — there is no server, no upload, no account.

## Put it online

1. Create a repository and push everything in this folder to `main`.
2. Settings → Pages → Source: **GitHub Actions**.
3. Push. The workflow runs the clinical test suite first and **refuses to deploy if any test fails**.

Your site: `https://<user>.github.io/<repo>/`

Everything is relative-path, so a project site (`/rxdx/`) and a user site both work
without edits. `.nojekyll` stops Jekyll from touching the files.

## Measured accuracy

Thirty hand-labelled clinical notes, in `gold/corpus.json`. Run `node tests/accuracy.js`.

| | |
|---|---|
| Principal diagnosis — precision | 61.4% |
| Principal diagnosis — recall | 77.1% |
| **F1** | **68.4%** |
| A denied finding is never coded | 100% (62 traps) |
| Drug names found | 100% |

These are a floor, not a boast: the suite fails if a change pushes them down.
Thirty notes is a direction, not a certification — a larger corpus of real
de-identified notes is the next step, and the labels need a coder's review
(`RxDx_Accuracy_Review.xlsx`).

## The local clinical model — read this before enabling it

The checkbox "Use the local clinical model" loads an OpenMed DISEASE NER model
into the browser tab. It was measured on the same 30 notes:

| configuration | F1 | denied findings kept out |
|---|---|---|
| Word list only (default, ships enabled) | **68.4%** | 100% |
| Model only | 52.2% | **34.4%** |
| Model, passed through the negation layer | 66.7% | 100% |
| **Word list + model together (what the checkbox does)** | **69.0%** | 100% |

The model tags every disease *mention*, including the ones the doctor denied.
On its own it coded two thirds of the findings written as "no ...". It is
therefore never run on its own: every span it returns is passed through the same
negation layer as the word list, and merged with it.

**The gain is +0.6 F1 for a ~335 MB download.** Recall rises meaningfully
(77.1% → 85.7%, three fewer missed codes across 30 notes), precision falls
(61.4% → 57.7%). Decide with those numbers in front of you.

### Hosting the model

GitHub caps a single file at 100 MB and a Pages site at 1 GB, so the model
cannot live in this repository. Put it on Hugging Face and point the tool at it:

1. Build the ONNX (needs ~8 GB RAM; the export itself needs no PyTorch):

   ```bash
   python3 openmed_tools/export_onnx.py <model-dir> ./onnx-build --quantize
   ```

   Produces `onnx/model.onnx` (fp32, ~1.3 GB) and `onnx/model_quantized.onnx`
   (int8, ~335 MB) plus the tokenizer files.

2. Upload `onnx-build/` to a Hugging Face model repo.
3. In RxDx: **Control Centre → local clinical model**, untick "served from our
   own server", and set the path to `<your-hf-user>/<your-model>`.

To keep it inside the hospital instead, serve `onnx-build/` from the hospital's
own web server and leave "served from our own server" ticked. Nothing then
leaves the network.

## What is in here

| | |
|---|---|
| `index.html` | the whole tool |
| `tests/` | 263 tests — run `node tests/<name>.js` |
| `gold/` | the labelled corpus and the accuracy harness |
| `preauth/` | the three payer protocols, parsed |
| `openmed_tools/` | ONNX export and offline analysis scripts |
| `backend/` | optional FastAPI service — not needed for the site |

## Contact

Mohammed Alshehri · m7md.alshehri68@gmail.com · https://www.linkedin.com/in/mh-sh68/
